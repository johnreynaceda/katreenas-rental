<?php return array (
  'appliance' => 'App\\Http\\Livewire\\Appliance',
  'boarder' => 'App\\Http\\Livewire\\Boarder',
  'dashboard' => 'App\\Http\\Livewire\\Dashboard',
  'logs' => 'App\\Http\\Livewire\\Logs',
  'payments' => 'App\\Http\\Livewire\\Payments',
  'qr' => 'App\\Http\\Livewire\\Qr',
  'report' => 'App\\Http\\Livewire\\Report',
  'room' => 'App\\Http\\Livewire\\Room',
  'user' => 'App\\Http\\Livewire\\User',
);